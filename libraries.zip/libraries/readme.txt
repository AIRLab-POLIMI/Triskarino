Arduino Libraries used in the project
